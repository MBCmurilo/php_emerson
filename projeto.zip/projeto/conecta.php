<?php
    $conn = mysqli_connect("sql.freedb.tech","freedb_MBCmurilo","qmS@p928GP2RfXj","freedb_murilo");
    mysqli_set_charset($conn,"utf8");
    if (!$conn) {
        echo "Error: Falha ao conectar-se ao servidor!".PHP_EOL;
        echo "Error: Falha ".mysqli_connect_error().PHP_EOL;
    }


?>